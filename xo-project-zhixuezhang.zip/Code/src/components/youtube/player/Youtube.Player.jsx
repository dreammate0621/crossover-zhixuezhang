import React, {Component} from 'react';
import { Link, Redirect } from 'react-router-dom';

import { YoutubeService } from '../../../services/youtube/Youtube';
import './Youtube.Player.scss';

const service = new YoutubeService();

class YoutubePlayer extends Component {
  constructor(props) {
    super(props);
    const id = window.location.href
      .replace(/^.*\//g, '')
      .replace(/^.*\..*/g, '');
    this.state = {
        valid: true,
        id
      };
    const iframe = '<iframe title="Video"' +
      '        width="100%"' +
      '        height="100%"' +
      '        src="https://www.youtube.com/embed/'+id+'?autoplay=1"'+
      '        frameBorder="0"'+
      '        allowFullScreen/>';
    setTimeout(() => {
      if (document.getElementsByClassName('frame-block')[0]) {
        document.getElementsByClassName('frame-block')[0].innerHTML = iframe;
      }
    }, 1000);

  }

  componentDidMount() {
    this.checkVideoId();
  }

  async checkVideoId() {
    this.setState({ valid: await service.checkVideoId(this.state.id) });
  }

  render() {
    if (!this.state.valid) {
      return (
        <Redirect to="/youtube"/>
      );
    }

    return (
      <div className="video-container">
        <div className="frame-block"/>
        <div className="controls">
          <Link className="btn btn-primary" to="/youtube"> &#60; Back to Trends</Link>
        </div>
      </div>);
  }
}

export default YoutubePlayer;
